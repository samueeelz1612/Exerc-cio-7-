function processarJSON() {
  const jsonTexto = document.getElementById("jsonInput").value;
  const output = document.getElementById("output");

  try {
    const dados = JSON.parse(jsonTexto);

    output.textContent = "";

    if (Array.isArray(dados)) {
      dados.forEach(item => {
        output.textContent += item.nome + "\n";
      });
    } else {
      output.textContent = "O JSON precisa ser uma lista (array) de produtos.";
    }
  } catch (erro) {
    output.textContent = "Erro: O formato inserido não é um JSON válido!";
  }
}

function exportarNovoJSON() {
  const output = document.getElementById("output");

  const novoProduto = {
    id: 101,
    nome: "Monitor Gamer 144Hz",
    categoria: "Eletrônicos",
    emEstoque: true
  };

  const jsonFormatado = JSON.stringify(novoProduto, null, 2);

  output.textContent = jsonFormatado;
}
