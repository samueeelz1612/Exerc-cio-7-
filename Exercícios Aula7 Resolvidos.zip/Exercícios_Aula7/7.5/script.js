let produtos = [];

function carregarProdutos() {
  fetch("produtos.json")
    .then(resposta => resposta.json())
    .then(dados => {
      produtos = dados;
      renderizar(produtos);
    })
    .catch(() => {
      alert("Não foi possível ler o arquivo produtos.json. Abra a página usando um servidor local (por exemplo, a extensão Live Server do VS Code).");
    });
}

function renderizar(lista) {
  const container = document.getElementById("gradeProdutos");
  container.innerHTML = "";

  if (lista.length === 0) {
    container.innerHTML = "<p>Nenhum produto encontrado.</p>";
    return;
  }

  lista.forEach(produto => {
    const card = document.createElement("div");
    card.className = "card-produto";

    card.innerHTML = `
      <h3>${produto.nome}</h3>
      <p>Categoria: ${produto.categoria}</p>
      <p class="preco">R$ ${produto.preco.toFixed(2).replace(".", ",")}</p>
    `;

    container.appendChild(card);
  });
}

function filtrarProdutos() {
  const texto = document.getElementById("filtroTexto").value.toLowerCase();
  const categoria = document.getElementById("filtroCategoria").value;

  const produtosFiltrados = produtos.filter(produto => {
    const bateuNome = produto.nome.toLowerCase().includes(texto);

    const bateuCategoria = categoria === "todas" || produto.categoria === categoria;

    return bateuNome && bateuCategoria;
  });

  renderizar(produtosFiltrados);
}

carregarProdutos();
