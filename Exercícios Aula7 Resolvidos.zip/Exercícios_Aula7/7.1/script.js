function atualizarPerfil() {
  const nome = "Maria Silva";
  const idade = 22;
  const bio = "Estudante de Engenharia de Computação, apaixonada por tecnologia e café.";

  document.getElementById("nome").textContent = nome;
  document.getElementById("idade").textContent = "Idade: " + idade;
  document.getElementById("biografia").textContent = bio;
}
